import { useEffect, useState } from "react";
import axios from "axios";
import ScaleLoader from "react-spinners/ScaleLoader";

import Show from "./Show";



function Main()
{
    const [arr,setArr] = useState([]);
    const [load,setLoad] = useState(true)

    function fetch()
        {
            setLoad(true)
            axios('https://randomuser.me/api/')
        .then((res)=>{
            console.log(res);
            setArr(res.data.results)
            setLoad(false)
        })
        .catch((err)=>{
            console.log("Error Fetchinf Data :",err);
            setLoad(false)
        })
        }

    useEffect(()=>{
        fetch()    
    },[])
    

    console.log(arr);


    return(
        <div id="main">
            <span>Fetch Random Data</span><br />
            <button className="btn btn-outline-dark" id="genBtn" onClick={fetch}>Generate</button>
            <div id="dataAdd">
                {
                    load ?
                     <ScaleLoader

                    color={'red'}
                    loading={50000}
                    // cssOverride={override}
                    size={250}
                    aria-label="Loading Spinner"
                    data-testid="loader"
                  /> : <Show  arr = {arr}/>
                }
            </div>
        </div>
    )
}

export default Main;