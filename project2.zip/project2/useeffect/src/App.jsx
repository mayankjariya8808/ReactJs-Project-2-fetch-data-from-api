import axios from 'axios';
import Main from './Component/Main';
import { useState } from 'react';
import { useEffect } from 'react';

function App() {


  

  const [arr,setrArr]= useState([])


  useEffect(()=>{


    axios('https://randomuser.me/api/')
    .then((res)=>{

      setrArr(res.data.results)
    })

  },[])


  return (
    <div className="App">

     
       
        <Main />
      
   
    
    </div>
  );
}
export default App;
